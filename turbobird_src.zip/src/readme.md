TurboBird is a Firebird Administration tool. It enables you to create new Firebird databases,
create/modify tables, procedures, views, triggers, generators, roles, UDFs, Domains, and much more.
Turbo Bird application is very easy to install and to use.

TurboBird uses Synapse package for http download.
http://wiki.freepascal.org/Synapse


# Blue Bits icons
License: These icons are free to use in any kind of commercial or non-commercial project unlimited times.
http://www.icojam.com/blog/?p=253

# Oxygen Icon Theme 
License: GPL
http://kde-look.org/content/show.php/Oxygen+Icons?content=74184

## Screenshots:
Main Window
![Main Window](https://cloud.githubusercontent.com/assets/536140/5899788/714d1712-a569-11e4-878e-066211bdb876.png)

Table
![Table](https://cloud.githubusercontent.com/assets/536140/5899791/7a2c37f0-a569-11e4-8d76-86480e1cb335.png)

View DDL
![View DDL](https://cloud.githubusercontent.com/assets/536140/5899792/7a5539a2-a569-11e4-95cc-81ed3b38c774.png)

Database Info
![Database Info](https://cloud.githubusercontent.com/assets/536140/5899793/7a681a72-a569-11e4-9bc6-d9419f6ec3f0.png)

New Database
![New Database](https://cloud.githubusercontent.com/assets/536140/5899794/7a77311a-a569-11e4-8da3-dba0c382e100.png)

Register Database
![Register Database](https://cloud.githubusercontent.com/assets/536140/5899795/7a7caec4-a569-11e4-9687-97ebaebd47d1.png)

Backup/Restore Database
![Backup/Restore Database](https://cloud.githubusercontent.com/assets/536140/5899796/7a8a1af0-a569-11e4-98de-a8e6928b1ce0.png)
