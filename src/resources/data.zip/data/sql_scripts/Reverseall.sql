drop table COUNTRIES;
drop View DeptList;
drop Procedure MyProc1;
drop Procedure MyProc2;
drop Procedure MyProc3;
Alter Table COUNTRY Drop Image;

