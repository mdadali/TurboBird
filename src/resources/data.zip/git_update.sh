#!/bin/bash

# Call the clean script first
./clean_src.sh

echo ""
echo "📦 Updating Git repository..."

# GitHub Username
GIT_USERNAME="mdadali"

# GitHub Access Token (bitte sicher aufbewahren)
GIT_TOKEN="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"

# Repository-URL (HTTP/HTTPS-URL mit Token)
REPO_URL="https://$GIT_USERNAME:$GIT_TOKEN@github.com/$GIT_USERNAME/TurboBird.git"

# Alle Änderungen hinzufügen
git add .

# Commit erstellen, wenn es Änderungen gibt
if ! git diff --cached --quiet; then
    git commit -m "Backup"
fi

# Push zum Remote-Repository
git push $REPO_URL main

echo "Änderungen wurden erfolgreich gepusht!"
